{
  /* Ba nomi Xudovandi baxshoyanda mehrubon va nihoyat Buzurg */
}
import React, { useEffect } from "react";
import "./App.css";
import { MessageTwoTone } from "@ant-design/icons";
import Switcher from "./Dark/Switcher";
import ShoppingBasketIcon from "@mui/icons-material/ShoppingBasket";
import AOS from "aos";
import "aos/dist/aos.css";
import { useTranslation } from "react-i18next";
import { Button, Modal } from "antd";
// img
import logo from "./assets/logo.svg";
import card1 from "./assets/card1.png";
import card2 from "./assets/card2.svg";
import img2 from "./assets/img2.png";
import img3 from "./assets/img3.png";
import img4 from "./assets/img4.png";
import group from "./assets/group.png";
import img5 from "./assets/img5.png";
import img8 from "./assets/img8.png";
import sircle from "./assets/sircle.svg";
import grid1 from "./assets/grid1.svg";
import car from "./assets/car.svg";
import iconsCard from "./assets/iconsCard.svg";
// swiper

import { useRef, useState } from "react";
// Import Swiper React components
import { Swiper, SwiperSlide } from "swiper/react";

// Import Swiper styles
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";

import "./styles.css";

// import required modules
import { Autoplay, Pagination, Navigation } from "swiper";
import ButtonOne from "./components/button/Button";
import CardOne from "./components/CardOne/CardOne";
import CardTwo from "./components/CardTwo/CardTwo";
// use State

const App = () => {
  const { t, i18n } = useTranslation();
  const changeLanguage = (language) => {
    i18n.changeLanguage(language);
  };

  const progressCircle = useRef(null);
  const progressContent = useRef(null);
  const onAutoplayTimeLeft = (s, time, progress) => {
    progressCircle.current.style.setProperty("--progress", 1 - progress);
    progressContent.current.textContent = `${Math.ceil(time / 1000)}s`;
  };
  const [data, setData] = useState([
    {
      id:1,
      p: "высокий доход",
      img: `${grid1}`,
      title:
        "Ежемесячно увеличивайте прибыль и достигайте поставленных целей, используя наши стратегии и рекомендации. Нет никаких ограничений по уровню доходаn",
    },
    {
      id:2,
      p: "высокий доход",
      img: `${grid1}`,
      title:
        "Ежемесячно увеличивайте прибыль и достигайте поставленных целей, используя наши стратегии и рекомендации. Нет никаких ограничений по уровню дохода",
    },
    {
      id:3,
      p: "высокий доход",
      img: `${grid1}`,
      title:
        "Ежемесячно увеличивайте прибыль и достигайте поставленных целей, используя наши стратегии и рекомендации. Нет никаких ограничений по уровню дохода",
    },
  ]);

  // modal

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [text,setText] = useState("")
  const [img,setImg] = useState("")
  const [title,setTitle] = useState("")
  const [modal, setModal] = useState(false);
  console.log(modal);
  const [idx, setIdx] = useState(null);
  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };

  const userAdd = (event) => {
    event.preventDefault();
    let arr = {
      p: event.target["text"].value,
      img: event.target["img"].value,
      title: event.target["paragraf"].value,
    };

    let todo = [...data, arr];
    setData(todo);
    setText("")
    setImg("")
    setTitle("")
  };
  function openModal(el) {
   setModal(true)
    setText(el.p)
    setImg(el.img)
    setTitle(el.title)
    setIdx(el.id)
    
  }
// user Edit
function userEdit( target){
  event.preventDefault()
    console.log(1);
}
  // function delete
  function deleteCard(id) {
    console.log(id);
    let arr2 = data.filter((elem) => {
      return elem.id != id;
    });

    setData(arr2);
  }

  useEffect(() => {
    AOS.init();
  }, []);

  return (
    <div className="dark:bg-black dark:text-white bg-[#F5FAFE]">
      <div className="container1">
        <section className="sec1">
          <header className=" dark:bg-black bg-transparent pb-28">
            <div className="container1">
              <nav className="flex justify-between p-[25px] items-center w-[97%] m-[0_auto] absolute z-[2]">
                <img src={logo} alt="" />
                <div className="flex gap-5 items-center">
                  <ul className=" sm:hidden lg:flex justify-between items-center gap-10">
                    <li>
                      <a href="#" className="uppercase text-black">
                        {t("text1")}
                      </a>
                    </li>
                    <li>
                      <a href="#" className="uppercase text-black">
                        {t("nav.t2")}
                      </a>
                    </li>
                    <li>
                      <a href="#" className="uppercase text-black">
                        materials
                      </a>
                    </li>
                    <li>
                      <a href="#" className="uppercase text-black">
                        dealers
                      </a>
                    </li>
                  </ul>
                  <div className="sm:hidden sm2:flex gap-6">
                    <ButtonOne className="" title={"Вход"} />
                    <ButtonOne title={"Регистрация"} />
                  </div>
                  <Switcher />
                  <button onClick={() => changeLanguage("en")}>En</button>
                  <button onClick={() => changeLanguage("ru")}>Ru</button>
                </div>
              </nav>
            </div>
          </header>

          <div className="w-[95%] m-[0_auto] flex flex-col gap-y-10 ">
            <h1 className=" sm:text-[25px] md:text-[60px] text-[#1C2D5A]  uppercase">
              запустите свой бизнес
            </h1>
            <p className=" sm:text-[25px] md:text-[100px] text-[#F99E4A] ml-[30%] ">
              за 1 день
            </p>
            <p className="sm:text-[25px] md:text-[60px] uppercase text-[#A8AFC0] ">
              не выходя из дома
            </p>
            <p className="sm:w-[90%] md:w-[30%] text-[#1C2D5A]">
              Воспользуйтесь высокодоходной бизнес-моделью и получайте прибыль
              онлайн. Узнайте все подробности программы после бесплатной
              регистрации.
            </p>
            <div className="flex items-center gap-10">
              <ButtonOne
                title={"зарегистрироваться"}
                bg="btnBg p-[10px_25px] rounded-xl text-white"
              />
              <ButtonOne
                title={"что мы предлагаем"}
                bg="bg-transparent border p-[10px_25px] rounded-xl text-[green] border-[green]"
              />
            </div>
          </div>
        </section>

        <section className="">
          <div className="w-[97%] m-[15px_auto] sm:grid-cols-2 md:grid-cols-3 grid lg:grid-cols-6 gap-14 text-center items-center">
            <div className="col-span-2">
              <img src={card1} alt="" />
            </div>
            <div className="flex flex-col gap-y-1">
              <img src={card2} className="w-[90px]" alt="" />
              <p>Минимальные риски и вложения</p>
            </div>
            <div className="flex flex-col gap-y-1">
              <img src={card2} className="w-[90px]" alt="" />
              <p>Минимальные риски и вложения</p>
            </div>
            <div className="flex flex-col gap-y-1">
              <img src={card2} className="w-[90px]" alt="" />
              <p>Минимальные риски и вложения</p>
            </div>
            <div className="flex flex-col gap-y-1">
              <img src={card2} className="w-[90px]" alt="" />
              <p>Минимальные риски и вложения</p>
            </div>
          </div>
        </section>

        <section className="">
          <div className="w-[97%] m-[45px_auto] grid sm:grid-cols-1 md3:grid-cols-2 gap-10 items-center">
            <img src={img2} alt="" />
            <div className="flex flex-col gap-y-5">
              <h1 className="text-[40px] text-[#1C2D5A]">
                получайте стабильный доход
              </h1>
              <p className="text-[24px] text-[#1C2D5A]">
                и повышайте качество жизни
              </p>
              <div className="flex flex-col gap-y-4">
                <p className="text-[20px] text-[#1C2D5A]">
                  Мы предлагаем вам готовую систему запуска , ведения и развития
                  онлайн-бизнеса с нуля.
                </p>
                <p className="text-[21px] text-[#1C2D5A]">В неё входят: </p>
                <div className="flex flex-col gap-y-8">
                  <div className="flex items-center gap-5">
                    <img src={sircle} alt="" />
                    <p className="text-[20px] text-[#1C2D5A]">
                      {" "}
                      эффективные инструменты интернет-маркетинга,{" "}
                    </p>
                  </div>
                  <div className="flex items-center gap-5">
                    <img src={sircle} alt="" />
                    <p className="text-[20px] text-[#1C2D5A]">
                      {" "}
                      инновационные эко-продукты для здоровья,{" "}
                    </p>
                  </div>
                  <div className="flex items-center gap-5">
                    <img src={sircle} alt="" />
                    <p className="text-[20px] text-[#1C2D5A]">
                      система бизнес-обучения и личностного развития{" "}
                    </p>
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-14 items-center">
                  <div className="flex flex-col gap-y-2 w-[200px]">
                    <p className="text-[60px] text-[#1C2D5A]">
                      500$ <span className="">+</span>
                    </p>
                    <p className="text-[22px] text-[#1C2D5A]">в месяц</p>
                  </div>
                  <div className="col-span-3">
                    <p>
                      Используя наш опыт и знания, вы сможете легко стать
                      интернет-предпринимателем с доходностью от 500$ в месяц в
                      нише эко-продуктов
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* section1 */}
      <div className="container1">
        <section className="">
          <div className="w-[97%] m-[45px_auto] ">
            <div className="grid md:grid-cols-2 lg:grid-cols-3  gap-10 gap-y-10">
              {data.map((el) => {
                return (
                  <div key={el.id}>
                    {console.log(el)}
                    <CardOne p={el.p} 
                             img={el.img} 
                             title={el.title} 
                             deleteBtn={() => deleteCard(el.id)}
                             onRemove={() => openModal(el)}
                             />
                  </div>
                );
              })}
              <div className="className=cardHover card flex flex-col justify-center items-center cursor-pointer rounded-2xl p-[80px_47px]  gap-y-8  bg-[#FFFEFC] shadow-xl">
                <p className="text-[85px]" onClick={showModal}>
                  +
                </p>
              </div>
            </div>
            <div>
              <Modal
                title="Basic Modal"
                open={isModalOpen}
                onOk={handleOk}
                onCancel={handleCancel}
              >
                <form
                  action=""
                  className="flex flex-col gap-y-3"
                  onSubmit={userAdd}
                >
                  <input
                    type="text"
                    className="p-[10px_20px] rounded-xl bg-white border-black border outline-none "
                    placeholder="input title"
                   
                    name="text"
                  />
                  <input
                    type="text"
                    className="p-[10px_20px] rounded-xl bg-white  border-black border  outline-none "
                    placeholder="input img"
                    name="img"
                   
                  />
                  <input
                    type="text"
                    className="p-[10px_20px] rounded-xl bg-white  border-black border  outline-none "
                    placeholder="input paragraf"
                   
                    name="paragraf"
                    id=""
                  />
                  <button className="border border-black p-[12px_45px] rounded-xl text-[24px] text-[green]">
                    Add
                  </button>
                </form>
              </Modal>
      
            </div>
          
            <div className="col-span-3 justify-center  items-center grid w-[100%] gap-y-3 ">
              <div className="flex flex-col items-center gap-y-5">
                <ButtonOne
                  title={"зарегистрироваться"}
                  bg="btnBg p-[10px_25px] rounded-xl text-white"
                />
                <p>
                  Регистрируйтесь в системе, чтобы узнать подробнее о доходах
                </p>
              </div>
            </div>
          
          </div>
        </section>

        <section className="">
          <div className="w-[87%] m-[45px_auto] flex flex-col items-center ">
            <h1 className="text-[40px] text-[#1C2D5A]">Что Вас ждет</h1>
            <p className="text-[#1C2D5A] text-[24px]">после регистрации</p>
            <div className="grid sm:grid-cols-1 md3:grid-cols-2 gap-10 items-center">
              <div className="flex flex-col gap-y-3">
                <h1 className="text-[#1C2D5A] text-[30px]">Обучение</h1>
                <p className="text-[#1C2D5A] text-[24px]">
                  всем необходимым знаниям для старта
                </p>
                <div>
                  <p className="text-[18px] text-[#1C2D5A]">
                    Мы подготовили практический онлайн-курс, где научим вас:{" "}
                  </p>
                  <div className="flex flex-col gap-y-8">
                    <div className="flex items-center gap-5">
                      <img src={sircle} alt="" />
                      <p className="text-[20px] text-[#1C2D5A]">
                        {" "}
                        эффективные инструменты интернет-маркетинга,{" "}
                      </p>
                    </div>
                    <div className="flex items-center gap-5">
                      <img src={sircle} alt="" />
                      <p className="text-[20px] text-[#1C2D5A]">
                        {" "}
                        инновационные эко-продукты для здоровья,{" "}
                      </p>
                    </div>
                    <div className="flex items-center gap-5">
                      <img src={sircle} alt="" />
                      <p className="text-[20px] text-[#1C2D5A]">
                        система бизнес-обучения и личностного развития{" "}
                      </p>
                    </div>
                    <p className="text-[18px] text-[#1C2D5A]">
                      С этими знаниями и при поддержке куратора, вы сможете
                      выйти на высокий уровень дохода уже через месяц
                    </p>
                  </div>
                </div>
              </div>
              <div>
                <img src={img3} alt="" />
              </div>
            </div>
            <div className="grid  sm:grid-cols-1 md3:grid-cols-2  gap-10 items-center">
              <div>
                <img src={img4} alt="" />
              </div>
              <div className="flex flex-col gap-y-3">
                <h1 className="text-[#1C2D5A] text-[30px]">Обучение</h1>
                <p className="text-[#1C2D5A] text-[24px]">
                  всем необходимым знаниям для старта
                </p>
                <div>
                  <p className="text-[18px] text-[#1C2D5A]">
                    Мы подготовили практический онлайн-курс, где научим вас:{" "}
                  </p>
                  <div className="flex flex-col gap-y-8">
                    <p className="text-[#1C2D5A] text-[20px]">
                      Уникальные формулы наших продуктов созданы по методу
                      синергизма, получены благодаря нативной вытяжке из
                      высокоэффективного сырья и на 100% состоят из натуральных
                      компонентов Вы сможете комплексно оздоровить свое тело,
                      укрепить иммунитет и улучшить самочувствие с помощью
                      инновационных эко-продуктов по специальным ценам для
                      партнеров
                    </p>
                    <p className="text-[18px] text-[#1C2D5A]">
                      С этими знаниями и при поддержке куратора, вы сможете
                      выйти на высокий уровень дохода уже через месяц
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="grid  sm:grid-cols-1 md3:grid-cols-2  gap-10 items-center">
              <div className="flex flex-col gap-y-3">
                <h1 className="text-[#1C2D5A] text-[30px]">Обучение</h1>
                <p className="text-[#1C2D5A] text-[24px]">
                  всем необходимым знаниям для старта
                </p>
                <div>
                  <p className="text-[18px] text-[#1C2D5A]">
                    Мы подготовили практический онлайн-курс, где научим вас:{" "}
                  </p>
                  <div className="flex flex-col gap-y-8">
                    <p className="text-[#1C2D5A] text-[20px]">
                      Уникальные формулы наших продуктов созданы по методу
                      синергизма, получены благодаря нативной вытяжке из
                      высокоэффективного сырья и на 100% состоят из натуральных
                      компонентов Вы сможете комплексно оздоровить свое тело,
                      укрепить иммунитет и улучшить самочувствие с помощью
                      инновационных эко-продуктов по специальным ценам для
                      партнеров
                    </p>
                    <p className="text-[18px] text-[#1C2D5A]">
                      С этими знаниями и при поддержке куратора, вы сможете
                      выйти на высокий уровень дохода уже через месяц
                    </p>
                  </div>
                </div>
              </div>
              <div>
                <img src={img5} alt="" />
              </div>
            </div>
          </div>
        </section>
        <section className="sec4 ">
          <div className="w-[80%] m-[0_auto]">
            <div className="cardImg ">
              <h1 className="text-[40px] text-[#1C2D5A]">
                развивайте свое дели получайте доход в партнерстве с нами
              </h1>

              <ButtonOne
                title={"зарегистрироваться"}
                bg="bg-[#39379F] text-white p-[14px_45px] rounded-xl"
              />
            </div>
          </div>
        </section>

        <section className="">
          <div className="w-[90%] m-[50px_auto] flex flex-col items-center gap-y-9 ">
            <h1 className="text-[40px] text-[#1C2D5A] ">
              {" "}
              Что ЕЩЕ вы получите
            </h1>
            <p>после регистрации</p>
            <div className="grid sm:grid-cols-1  lg:grid-cols-2 items-end gap-10">
              <div>
                <img src={img8} className="w-[100%]" alt="" />
              </div>
              <div className="grid sm:grid-cols-1 md1:grid-cols-2 gap-4">
                <CardTwo
                  img={iconsCard}
                  title={"Пошаговое онлайн-обучение и руководство по запуску"}
                />
                <CardTwo
                  img={iconsCard}
                  title={"Пошаговое онлайн-обучение и руководство по запуску"}
                />
                <CardTwo
                  img={iconsCard}
                  title={"Пошаговое онлайн-обучение и руководство по запуску"}
                />
                <CardTwo
                  img={iconsCard}
                  title={"Пошаговое онлайн-обучение и руководство по запуску"}
                />
                <CardTwo
                  img={iconsCard}
                  title={"Пошаговое онлайн-обучение и руководство по запуску"}
                />
                <CardTwo
                  img={iconsCard}
                  title={"Пошаговое онлайн-обучение и руководство по запуску"}
                />
              </div>
            </div>
          </div>
        </section>
        <section className="sec5 ">
          <div className="w-[97%] m-[0_auto]  grid  sm:grid-cols-1 md:grid-cols-2 justify-center gap-10 items-center gap-y-9 ">
            <div className="flex flex-col gap-y-10">
              <h1 className="text-[40px] text-white font-bold">
                выход на новый уровень жизни
              </h1>
              <p className="text-[20px] text-white">
                В партнерстве с нами вы посмотрите на Мир под другим углом —
                почувствуете себя в зоне комфорта, личностного роста и
                финансового изобилия
              </p>
              <div className="flex gap-8 items-center">
                <p className="text-[26px] text-[#F09642]">+</p>
                <p className="text-white">Премиальныебонусы</p>
              </div>
            </div>
            <div>
              <h1>Привилегии для партнеров</h1>
              <div className="grid sm:grid-cols-2   md3:grid-cols-3 gap-7">
                <div className="flex flex-col gap-y-2">
                  <img src={car} alt="" />
                  <p className="text-white">Авто и недвижимость от компании</p>
                </div>
                <div className="flex flex-col gap-y-2">
                  <img src={car} alt="" />
                  <p className="text-white">Авто и недвижимость от компании</p>
                </div>
                <div className="flex flex-col gap-y-2">
                  <img src={car} alt="" />
                  <p className="text-white">Авто и недвижимость от компании</p>
                </div>
                <div className="flex flex-col gap-y-2">
                  <img src={car} alt="" />
                  <p className="text-white">Авто и недвижимость от компании</p>
                </div>
                <div className="flex flex-col gap-y-2">
                  <img src={car} alt="" />
                  <p className="text-white">Авто и недвижимость от компании</p>
                </div>
                <div className="flex flex-col gap-y-2">
                  <img src={car} alt="" />
                  <p className="text-white">Авто и недвижимость от компании</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="footer flex items-center ">
          <div className="flex flex-col items-center justify-center gap-y-5 w-[100%]">
            <h1 className="text-[40px] leading-tight text-white uppercase">
              Начните менять свою жизнь уже сегодня
            </h1>
            <button className="btnBg p-[12px_35px] rounded-xl">
              зарегистрироваться
            </button>
          </div>{" "}
        </section>
        <footer className="bg-[#1C2D5A] sm:flex-col sm2:flex-row sm:gap-y-4 flex justify-between items-center p-[20px_25px] ">
          <img src={logo} alt="" />
          <img src={group} alt="" />
        </footer>
        {modal ? (
        
          <div className="modal">
               console.log(1)
          <div className="modal-content">
            <span
              onClick={() => setModal(false)}
              className="float-right cursor-pointer"
            >
              x
            </span>
            <div>
            <form
                  action=""
                  className="flex flex-col gap-y-3"
                  onSubmit={userEdit}
                >
                  <input
                    type="text"
                    className="p-[10px_20px] rounded-xl bg-white border-black border outline-none "
                    placeholder="input title"
                    value={text}
                     onChange={(event) => setText(event.target.value)}
                    name="text"
                  />
                  <input
                    type="text"
                    className="p-[10px_20px] rounded-xl bg-white  border-black border  outline-none "
                    placeholder="input img"
                    name="img"
                    value={img}
                     onChange={(event) => setImg(event.target.value)}
                  />
                  <input
                    type="text"
                    className="p-[10px_20px] rounded-xl bg-white  border-black border  outline-none "
                    placeholder="input paragraf"
                    value={title}
                    onChange={(event)=> setTitle(event.target.value)}
                    name="paragraf"
                    id=""
                  />
                  <button className="border border-black p-[12px_45px] rounded-xl text-[24px] text-[green]">
                    Add
                  </button>
                </form>
            </div>
          </div>
        </div>
      ) : null}
      </div>
    </div>
  );
};
// export {openModal}

export default App;
