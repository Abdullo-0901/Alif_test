import { Image } from "antd";
import React from "react";
import "./card1.css";
import EditIcon from '@mui/icons-material/Edit';
import RestoreFromTrashIcon from '@mui/icons-material/RestoreFromTrash';
// import { openModal } from '../../App';
const CardOne = (props) => {
  const { img, title, p, onRemove,deleteBtn } = props
  return (
    <div className="cardHover card flex flex-col rounded-2xl p-[80px_47px]  gap-y-8  bg-[#FFFEFC] shadow-xl">
      <p className="text-black text-[24px] uppercase">{p}</p>
      <Image src={img} style={{ width: "80px" }} />

      <p className="text-[black] text-[18px]">{title}</p>
      <div className='flex gap-8'>
                <EditIcon  style={{color:'green',cursor:'pointer'}}  onClick={() =>{props.onRemove()} }  />
                <RestoreFromTrashIcon style={{color:'red'}}  onClick={() =>{props.deleteBtn()}} />
              </div>
    </div>
  );
};

export default CardOne;
