import { Image } from "antd";
import React from "react";

// import { openModal } from '../../App';
const CardTwo = ({ img, title, p }) => {
  return (
    <div className="cardHover card flex flex-col rounded-2xl p-[20px_47px]  gap-y-8  h-[290px] bg-[#FFFEFC] shadow-xl">
      <p className="text-black text-[24px] uppercase">{p}</p>
      <Image src={img} style={{ width: "80px" }} />

      <p className="text-[black] text-[18px]">{title}</p>
    </div>
  );
};

export default CardTwo;
