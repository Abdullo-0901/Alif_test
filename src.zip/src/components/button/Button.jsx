import React from 'react'

const ButtonOne = ({title,bg}) => {
  return (
    <div>
        <button className={bg}>{title}</button>
    </div>
  )
}

export default ButtonOne